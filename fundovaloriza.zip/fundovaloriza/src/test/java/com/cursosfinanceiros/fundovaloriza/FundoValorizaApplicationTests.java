package com.cursosfinanceiros.fundovaloriza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundoValorizaApplicationTests {

	@Test
	void contextLoads() {
	}

}
