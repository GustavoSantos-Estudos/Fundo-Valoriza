package com.cursosfinanceiros.fundovaloriza.services;

import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import com.cursosfinanceiros.fundovaloriza.repositories.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;  // Injetando o PasswordEncoder para criptografar as senhas

    // Método para cadastrar o usuário
    public Usuario cadastrarUsuario(Usuario usuario) {
        // Verifica se o e-mail já está cadastrado
        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioExistente.isPresent()) {
            throw new EmailAlreadyExistsException("E-mail já cadastrado.");
        }

        // Se o usuário for autenticado via Google, não há necessidade de senha
        if (usuario.isAutenticadoComGoogle() && usuario.getSenha() == null) {
            usuario.setSenha(""); // Para o cadastro via Google, deixamos a senha como vazia
        } else if (!usuario.isAutenticadoComGoogle() && usuario.getSenha() != null) {
            // Criptografa a senha se não for via Google
            usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
        }

        // Salva o usuário no banco
        return usuarioRepository.save(usuario);
    }

    // Método para buscar usuário por e-mail
    public Optional<Usuario> buscarPorEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    public boolean validarSenha(String senhaOriginal, String senhaCriptografada) {
        return passwordEncoder.matches(senhaOriginal, senhaCriptografada);
    }

    // Método para verificar se o e-mail já existe
    public boolean verificarEmailExistente(String email) {
        return usuarioRepository.findByEmail(email).isPresent();
    }

    // Método do Spring Security para carregar o usuário durante o login
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuário não encontrado"));
        return buildUser(usuario);
    }

    // Método para carregar um usuário OAuth2 (Google)
    public UserDetails loadOAuth2UserByUsername(OAuth2User oauth2User) {
        // Caso o usuário seja autenticado via Google, podemos pegar o nome diretamente do OAuth2User
        String username = oauth2User.getAttribute("name"); // Ou 'email' se for o caso
        return buildOAuth2User(username);
    }

    private UserDetails buildUser(Usuario usuario) {
        // Construção do objeto UserDetails com base no usuário tradicional
        User.UserBuilder builder = User.withUsername(usuario.getNome())  // Usando o nome do usuário
                .authorities("ROLE_USER");

        // Se autenticado com Google, senha é vazia
        if (usuario.isAutenticadoComGoogle()) {
            builder.password("");  // Senha vazia para usuários autenticados via Google
        } else {
            builder.password(usuario.getSenha());  // Senha criptografada
        }

        return builder.build();
    }

    private UserDetails buildOAuth2User(String username) {
        // Construção do objeto UserDetails com base no nome do usuário do OAuth2
        return User.withUsername(username)  // Nome do usuário vindo do Google
                .authorities("ROLE_USER")
                .password("")  // Usuário autenticado via Google não tem senha
                .build();
    }
}

// Exceção personalizada para e-mail já existente
class EmailAlreadyExistsException extends RuntimeException {
    public EmailAlreadyExistsException(String message) {
        super(message);
    }
}
