package com.cursosfinanceiros.fundovaloriza.config;

import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class SecurityConfig {

    private final UsuarioService usuarioService;
    private final PasswordEncoder passwordEncoder;
    private final CustomAuthenticationFailureHandler failureHandler;

    public SecurityConfig(UsuarioService usuarioService, PasswordEncoder passwordEncoder, CustomAuthenticationFailureHandler failureHandler) {
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
        this.failureHandler = failureHandler;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(authorize -> authorize
                        .requestMatchers("/", "/auth/**", "/css/**", "/js/**", "/imagens/**", "/fonts/**", "/webjars/**")
                        .permitAll()  // Permite acesso a páginas sem autenticação
                        .anyRequest().authenticated()  // Requer autenticação para outras páginas
                )
                .formLogin(form -> form
                        .loginPage("/auth/login")  // Página de login personalizada
                        .failureHandler(failureHandler)  // Usando o CustomAuthenticationFailureHandler
                        .permitAll()
                )
                .oauth2Login(oauth2 -> oauth2
                        .loginPage("/auth/login")  // Página de login personalizada
                        .defaultSuccessUrl("/home", true)  // Redireciona para a página inicial após o login
                        .failureUrl("/auth/login?error=true")  // Redireciona em caso de falha no login
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/")  // Redireciona para a página inicial após o logout
                        .invalidateHttpSession(true)
                        .permitAll()
                )
                .sessionManagement(session -> session
                        .invalidSessionUrl("/auth/login")
                        .maximumSessions(1)
                        .maxSessionsPreventsLogin(false)
                )
                .csrf(csrf -> csrf
                        .disable()  // Desabilita CSRF se necessário
                );

        return http.build();
    }

    @Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        AuthenticationManagerBuilder authenticationManagerBuilder =
                http.getSharedObject(AuthenticationManagerBuilder.class);
        authenticationManagerBuilder.userDetailsService(usuarioService).passwordEncoder(passwordEncoder);
        return authenticationManagerBuilder.build();
    }
}

