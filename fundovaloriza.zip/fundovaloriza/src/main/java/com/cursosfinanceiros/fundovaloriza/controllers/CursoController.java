package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.models.Curso;
import com.cursosfinanceiros.fundovaloriza.services.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CursoController {

    @Autowired
    private CursoService cursoService;

    // Exibir a lista de cursos
    @GetMapping("/cursos")
    public String listarCursos(Model model) {
        model.addAttribute("cursos", cursoService.listarTodosCursos());
        return "cursos";  // Template cursos.html
    }

    // Exibir o formulário para criar um novo curso
    @GetMapping("/cursos/novo")
    public String exibirFormularioCriacao(Model model) {
        model.addAttribute("curso", new Curso());
        model.addAttribute("cursos", cursoService.listarTodosCursos()); // ADICIONA ISSO
        return "formularioCurso";
    }


    // Processar o formulário de criação de curso
    @PostMapping("/cursos")
    public String criarCurso(@ModelAttribute Curso curso) {
        cursoService.salvarCurso(curso);
        return "redirect:/cursos";  // Redireciona para a lista de cursos
    }

    // Exibir o formulário para editar um curso existente
    @GetMapping("/cursos/editar/{id}")
    public String exibirFormularioEdicao(@PathVariable("id") String id, Model model) {
        Curso curso = cursoService.buscarCursoPorId(id);
        model.addAttribute("curso", curso);
        return "formularioCurso";  // Template formularioCurso.html
    }

    // Processar o formulário de edição de curso
    @PostMapping("/cursos/editar/{id}")
    public String editarCurso(@PathVariable("id") String id, @ModelAttribute Curso curso) {
        curso.setId(id);  // Garantir que o ID seja mantido
        cursoService.salvarCurso(curso);
        return "redirect:/cursos";  // Redireciona para a lista de cursos
    }

    // Excluir um curso
    @GetMapping("/cursos/excluir/{id}")
    public String excluirCurso(@PathVariable("id") String id) {
        cursoService.deletarCurso(id);
        return "redirect:/cursos";  // Redireciona para a lista de cursos
    }

    @GetMapping("/inscrever/{id}")
    public String inscreverNoCurso(@PathVariable("id") String cursoId) {
        // Aqui você pode registrar a inscrição no banco, se quiser (opcional)
        return "redirect:/aulas?id=" + cursoId;
    }

}
