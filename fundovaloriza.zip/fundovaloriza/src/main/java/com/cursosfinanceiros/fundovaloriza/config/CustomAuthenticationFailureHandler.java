package com.cursosfinanceiros.fundovaloriza.config;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;
import org.springframework.security.core.AuthenticationException;

import jakarta.servlet.http.HttpServletRequest;  // Atualizado para jakarta.servlet
import jakarta.servlet.http.HttpServletResponse;  // Atualizado para jakarta.servlet
import java.io.IOException;

import org.springframework.web.util.UriComponentsBuilder;

@Component
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
                                        AuthenticationException exception) throws IOException {

        String errorMessage = "Invalid credentials";  // Default error message

        if (exception instanceof BadCredentialsException) {
            errorMessage = "Senha incorreta. Tente novamente.";
        } else {
            errorMessage = "Email não cadastrado.";
        }

        String redirectUrl = UriComponentsBuilder.fromUriString("/auth/login")
                .queryParam("error", true)
                .queryParam("message", errorMessage)
                .build().toUriString();
        response.sendRedirect(redirectUrl);  // Redireciona para a página de login com o erro
    }
}
