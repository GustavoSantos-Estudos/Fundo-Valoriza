package com.cursosfinanceiros.fundovaloriza.repositories;

import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface UsuarioRepository extends MongoRepository<Usuario, String> {
    Optional<Usuario> findByEmail(String email);

    // Caso queira adicionar mais métodos customizados, você pode fazer aqui
    void deleteByEmail(String email);  // Exemplo de método customizado
}
