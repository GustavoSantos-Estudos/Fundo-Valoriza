package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.models.Aula;
import com.cursosfinanceiros.fundovaloriza.services.AulaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AulaController {

    @Autowired
    private AulaService aulaService;

    @GetMapping("/aulas")
    public String listarAulas(@RequestParam("id") String cursoId, Model model) {
        model.addAttribute("aulas", aulaService.listarAulasPorCurso(cursoId));
        model.addAttribute("aula", new Aula());
        model.addAttribute("cursoId", cursoId);
        return "aulas";
    }

    @PostMapping("/aulas")
    public String adicionarAula(@ModelAttribute Aula aula, @RequestParam("cursoId") String cursoId) {
        aula.setCursoId(cursoId);

        // Conversão automática de YouTube watch para embed
        if (aula.getUrlVideo() != null && aula.getUrlVideo().contains("watch?v=")) {
            String embedUrl = aula.getUrlVideo().replace("watch?v=", "embed/");
            aula.setUrlVideo(embedUrl);
        }

        aulaService.salvarAula(aula);
        return "redirect:/aulas?id=" + cursoId;
    }

    @GetMapping("/aulas/editar/{id}")
    public String exibirFormularioEdicao(@PathVariable("id") String id, Model model) {
        Aula aula = aulaService.buscarPorId(id);
        model.addAttribute("aula", aula);
        model.addAttribute("cursoId", aula.getCursoId());
        model.addAttribute("aulas", aulaService.listarAulasPorCurso(aula.getCursoId()));
        return "aulas"; // reutilizando o mesmo template
    }

    @PostMapping("/aulas/editar/{id}")
    public String editarAula(@PathVariable("id") String id, @ModelAttribute Aula aula, @RequestParam("cursoId") String cursoId) {
        aula.setId(id);
        aula.setCursoId(cursoId);

        if (aula.getUrlVideo() != null && aula.getUrlVideo().contains("watch?v=")) {
            aula.setUrlVideo(aula.getUrlVideo().replace("watch?v=", "embed/"));
        }

        aulaService.salvarAula(aula);
        return "redirect:/aulas?id=" + cursoId;
    }

    @GetMapping("/aulas/excluir/{id}")
    public String excluirAula(@PathVariable("id") String id, @RequestParam("cursoId") String cursoId) {
        aulaService.deletarAula(id);
        return "redirect:/aulas?id=" + cursoId;
    }
}
