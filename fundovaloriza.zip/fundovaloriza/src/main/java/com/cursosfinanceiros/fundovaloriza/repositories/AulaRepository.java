package com.cursosfinanceiros.fundovaloriza.repositories;

import com.cursosfinanceiros.fundovaloriza.models.Aula;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface AulaRepository extends MongoRepository<Aula, String> {
    List<Aula> findByCursoId(String cursoId);
    List<Aula> findByCursoIdOrderByIdDesc(String cursoId); // Mongo vai ordenar por ID, que é crescente cronologicamente

}
