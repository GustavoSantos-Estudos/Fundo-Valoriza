package com.cursosfinanceiros.fundovaloriza.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "aulas")
public class Aula {

    @Id
    private String id;
    private String titulo;
    private String urlVideo;
    private String cursoId;

    public Aula() {}

    public Aula(String titulo, String urlVideo, String cursoId) {
        this.titulo = titulo;
        this.urlVideo = urlVideo;
        this.cursoId = cursoId;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getUrlVideo() { return urlVideo; }
    public void setUrlVideo(String urlVideo) { this.urlVideo = urlVideo; }

    public String getCursoId() { return cursoId; }
    public void setCursoId(String cursoId) { this.cursoId = cursoId; }
}
