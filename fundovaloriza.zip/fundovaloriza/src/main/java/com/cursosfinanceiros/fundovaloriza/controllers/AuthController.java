package com.cursosfinanceiros.fundovaloriza.controllers;

import com.cursosfinanceiros.fundovaloriza.models.Usuario;
import com.cursosfinanceiros.fundovaloriza.services.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    // Página de login
    @GetMapping("/auth/login")
    public String exibirLogin() {
        return "login";  // Renderiza o template de login
    }

    // Página de cadastro
    @GetMapping("/auth/cadastro")
    public String exibirCadastro() {
        return "cadastro";  // Renderiza o template de cadastro
    }

    // Processar o cadastro
    @PostMapping("/auth/cadastro")
    public String processarCadastro(@Validated Usuario usuario, BindingResult result, Model model) {
        // Verifica se houve erros de validação (como campos obrigatórios não preenchidos)
        if (result.hasErrors()) {
            model.addAttribute("erro", "Por favor, preencha todos os campos corretamente.");
            return "cadastro";  // Retorna à página de cadastro se houver erros de validação
        }

        try {
            // Verifica se o e-mail já está cadastrado
            if (usuarioService.verificarEmailExistente(usuario.getEmail())) {
                model.addAttribute("erro", "E-mail já cadastrado. Tente outro.");
                return "cadastro";  // Retorna à página de cadastro com erro
            }

            // Cadastra o usuário
            usuarioService.cadastrarUsuario(usuario);
            model.addAttribute("sucesso", "Cadastro realizado com sucesso!");
            return "redirect:/auth/login";  // Redireciona para a página de login após o cadastro

        } catch (Exception e) {
            // Exibe erro caso ocorra uma exceção durante o cadastro
            model.addAttribute("erro", "Erro ao cadastrar usuário: " + e.getMessage());
            return "cadastro";  // Retorna à página de cadastro com erro
        }
    }

    // Página de home (exemplo de redirecionamento após login)
    @GetMapping("/home")
    public String home() {
        return "home";  // Renderiza o template de home
    }
}
