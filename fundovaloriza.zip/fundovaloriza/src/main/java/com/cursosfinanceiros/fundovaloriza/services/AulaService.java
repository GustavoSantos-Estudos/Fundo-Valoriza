package com.cursosfinanceiros.fundovaloriza.services;

import com.cursosfinanceiros.fundovaloriza.models.Aula;
import com.cursosfinanceiros.fundovaloriza.repositories.AulaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AulaService {

    @Autowired
    private AulaRepository aulaRepository;

    public List<Aula> listarAulasPorCurso(String cursoId) {
        return aulaRepository.findByCursoIdOrderByIdDesc(cursoId); // mais recentes primeiro
    }


    public void salvarAula(Aula aula) {
        aulaRepository.save(aula);
    }

    public void deletarAula(String id) {
        aulaRepository.deleteById(id);
    }

    public Aula buscarPorId(String id) {
        return aulaRepository.findById(id).orElse(null);
    }

}
