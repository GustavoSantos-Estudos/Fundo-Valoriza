package com.cursosfinanceiros.fundovaloriza.controllers;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model model, Authentication auth) {
        if (auth != null && auth.isAuthenticated()) {
            System.out.println("🔐 Usuário autenticado: " + auth.getName());
        } else {
            System.out.println("🔓 Ninguém autenticado.");
        }
        return "home";
    }

    @GetMapping("/parcerias")
    public String parcerias() {
        return "parcerias"; // retorna parcerias.html
    }

    @GetMapping("/sobre")
    public String sobre() {
        return "sobre"; // retorna sobre.html
    }

    @GetMapping("/contato")
    public String contato() {
        return "contato"; // retorna contato.html
    }
}
